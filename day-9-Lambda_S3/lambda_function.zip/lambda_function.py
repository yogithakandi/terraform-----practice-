def lambda_handler(event, context):
    return {"statusCode": 200, "body": "Hello  from lambda to s3 welcome to my page !"}